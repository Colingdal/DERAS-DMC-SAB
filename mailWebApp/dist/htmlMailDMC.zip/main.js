define(function (require) {
  'use strict';

  var Component = require('Component');
  var template = require('/template/main');
  var Toasts = require('toasts');
  var requester = require('requester');
  var router = require('router');
  var _ = require('underscore');
  var $ = require('jquery');
  return Component.extend({
    template: template,
    events: {
      dom: {
        'click [data-send]': 'sendingMail'
      }
    },
    sendingMail: function sendingMail(e) {
      e.preventDefault();
      var mailobj = {
        headline: $('#text-1').val(),
        email: $('#email').val()
      };
      requester.doPost({
        url: router.getUrl('/sendMailInfo'),
        data: mailobj
      }).then(function (response) {
        console.log('Send: ', response);
        Toasts.publish({
          heading: 'Mail',
          message: 'Skickat! :)',
          type: 'primary'
        });
        $('#text-1').val('');
        $('#email').val('');
      })["catch"](function (response) {
        console.log('Fail', response);
        Toasts.publish({
          heading: 'Mail',
          message: 'Kunde inte skicka, Försök igen! :(',
          type: 'danger'
        });
      });
    }
  });
});