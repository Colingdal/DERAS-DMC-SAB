define(function (require) {
  'use strict';

  var properties = require('Properties');
  var portletContextUtil = require('PortletContextUtil');
  var mailBuilder = require('MailBuilder');
  var logUtil = require('LogUtil');
  var outputUtil = require("OutputUtil");
  var appData = require('appData');
  var page = appData.getNode('page');
  var resourceLocatorUtil = require('ResourceLocatorUtil');
  var webContentUtil = require('WebContentUtil');
  var $ = require('jquery');
  var pagePart = page.getIdentifier() + '_pageContent';
  var pagePartNode = resourceLocatorUtil.getNodeByIdentifier(pagePart);
  var iterator = pagePartNode.getNodes();
  var pagePartNodeFound;
  while (iterator.hasNext()) {
    var child = iterator.nextNode();
    if (properties.get(child, 'jcr:uuid').startsWith('94')) {
      pagePartNodeFound = child;
    }
  }
  var currentpage = portletContextUtil.getCurrentPage();
  var pageiterator = currentpage.getNodes();
  var pageHtml;
  while (pageiterator.hasNext()) {
    var pchild = pageiterator.nextNode();
    if (properties.get(pchild, 'displayName') && properties.get(pchild, 'jcr:uuid').startsWith('4.')) {
      pageHtml = pchild;
    }
  }
  return {
    getCurrentUser: function getCurrentUser() {
      var currentuser = portletContextUtil.getCurrentUser();
      var mail = properties.get(currentuser, 'mail') ? properties.get(currentuser, 'mail') : '';
      return {
        mail: mail
      };
    },
    sendMail: function sendMail(params) {
      var htmlvalue = outputUtil.getNodeOutput(page, pagePartNodeFound, 1);
      var mailadress = appData.get('mail');
      var mail = mailBuilder.setSubject(params.headline).setHtmlMessage(htmlvalue + '<br><div><input type="checkbox" name="prenumeration"/><label>Vill du prenumera på detta nyhetsbrev?</label></div>').addRecipient(params.email).setFrom(mailadress).build();
      var successfullmail = mail.send();
      if (successfullmail === true) {
        webContentUtil.appendContent(pageHtml, '<div><a name="' + params.email + ' " />' + params.email + '</div>');
      } else {}
      return successfullmail;
    }
  };
});