(function () {
  'use strict';

  var router = require('router');
  var logUtil = require('LogUtil');
  var mail = require('/module/server/mail');
  var appData = require('appData');
  function renderIndex(req, res, data) {
    if (req.xhr) {
      logUtil.info('AJAX: ' + JSON.stringify(data));
      res.json(data);
    } else {
      logUtil.info('Render: ' + JSON.stringify(data));
      res.render('/', data);
    }
  }
  router.get('/', function (req, res) {
    var user = mail.getCurrentUser();
    // const prenumeration = appData.get('prenumeration')
    // logUtil.info('prenumeration, ' + prenumeration);
    var data = {
      mail: user.mail
    };
    renderIndex(req, res, data);
  });
  router.post('/sendMailInfo', function (req, res) {
    var content = mail.sendMail(req.params);
    //const prenumeration = appData.get('prenumeration')
    if (content === true) {
      res.json({
        mailok: content
      });
      // console.log(prenumeration);
    }
  });
})();

//Request is message that arrive to server for request something.

//Response is message that send from server to client for give thing that client what.

//GET is used to request data from a specified resource.

//POST is used to send data to a server to create/update a resource.