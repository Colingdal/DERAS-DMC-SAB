define(function (require) {
  'use strict';

  var properties = require('Properties');
  var portletContextUtil = require('PortletContextUtil');
  var mailBuilder = require('MailBuilder');
  var logUtil = require('LogUtil');
  // const outputUtil = require("OutputUtil");
  // const page = appData.getNode('page');

  // const htmlvalue = outputUtil.getNodeOutput(page, null, 1);
  // logUtil.info('html, ' + htmlvalue);

  // const htmlMessage = mailBuilder.setHtmlMessage(htmlvalue);
  // logUtil.info('message, ' + htmlMessage);

  return {
    getCurrentUser: function getCurrentUser() {
      var currentuser = portletContextUtil.getCurrentUser();
      var mail = properties.get(currentuser, 'mail') ? properties.get(currentuser, 'mail') : '';
      return {
        mail: mail
      };
    },
    sendMail: function sendMail(params) {
      var mail = mailBuilder.setSubject(params.headline).setHtmlMessage('<h1>hej</h1>').addRecipient(params.email).setFrom(params.from).build();
      return mail.send();
    }
  };
});