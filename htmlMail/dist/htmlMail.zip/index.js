(function () {
  "use strict";

  var router = require("router");
  var appData = require("appData");
  router.get("/", function (req, res) {
    var message = "Hello, world!";
    var name = appData.get("name");
    res.render("/", {
      message: message,
      name: name
    });
  });
})();