define(function (require) {
  'use strict';

  var _ = require('underscore');

  var Component = require('Component');

  var template = require('/template/main');

  return Component.extend({
    template: template,
    filterState: function filterState(state) {
      return _.extend({}, {
        pages: state.pages
      });
    }
  });
});