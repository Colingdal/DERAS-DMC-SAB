(function () {
  'use strict';

  var router = require('router');

  var myModule = require('/module/server/myModule');

  var logUtil = require('LogUtil');

  var resourceLocatorUtil = require('ResourceLocatorUtil'); //Lokaliserar resurser
  //const sitePage = resourceLocatorUtil.getSitePage();


  var properties = require('Properties');

  var portletContextUtil = require('PortletContextUtil');

  var currentPage = portletContextUtil.getCurrentPage();
  router.get('/', function (req, res) {
    //var result = {};
    var headPage = {
      // Skapar objekt med egenskaper från sitePage och använder metoden getIdentifier för att få id. Skapar tom barn array
      name: properties.get(currentPage, 'displayName'),
      URI: properties.get(currentPage, 'URI'),
      id: currentPage.getIdentifier(),
      children: []
    };
    var pages = myModule.childrenPages(headPage);
    return res.render('/', {
      pages: JSON.stringify(pages)
    });
  });
})();