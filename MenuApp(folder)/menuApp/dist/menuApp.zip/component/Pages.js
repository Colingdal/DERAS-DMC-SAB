define(function (require) {
  'use strict';

  var _ = require('underscore');

  var Component = require('Component');

  var template = require('/template/pages');

  return Component.extend({
    template: template,
    onRendered: function onRendered() {// console.log('Pages.js onRendered', this.state.pages);
    },
    filterState: function filterState(state) {
      return _.extend({}, {
        pages: state.pages
      });
    }
  });
});